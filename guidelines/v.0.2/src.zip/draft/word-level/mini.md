# 1. Background and Terminology

A coherent, meaningful text can be characterized by three conditions, (semantic) consistency, (pragmatic) relevance, and cohesion (or, "connectedness"). In this manual, we focus on the annotation and subsequent analysis of the latter condition, i.e., we aim to elucidate **cohesion**, or connectedness, i.e., how each sentence is linked to an adjacent sentence in the text by means of

1. anaphoric (referring) expressions,
2. a linguistic marker for the introduction of a new topic, or
3. a semantic sentence connector ("cues").

This definition (loosely following Reinhart 1980, p.168) involves three types of analysis, i.e., 

1. the annotation of (co-)reference (what are referring expressions in the text, which entities do they refer to), 
2. the annotation of topichood (what is the entity the current sentence is about), and
3. shallow discourse annotation (what are the discourse markers used, which relations do they indicate, and which utterances do they refer to)

We further limit ourselves on the first and second aspect, i.e., referring expressions and the annotation of topic continuity. Shallow discourse annotation is to be done independently, e.g., according to the schema of the Penn Discourse Treebank (Webber et al. 2019).

Coherent texts thus involve repeated mentions of the same entity as well as references to objects related in various ways to what has already been discussed, and moreover, the utterances within a coherent text are construed *about* these referents. Annotating corpora with information about such relations between elements of a text is useful both from a linguistic point of view and for applications such as information extraction.

Subsequent mentions of an entity can have the same surface form - as when the expression *the Lord Provost* is encountered twice in a text - or different ones. Anaphoric expressions are used to indicate that elements of a text are correlated. The simplest forms of anaphoric expression are used to indicate a subsequent mention of an object already introduced: typical examples of this type of anaphoric expression are pronouns such as *he* in the text *John arrived. [He] looked tired.* In the preferred reading of this text, the pronoun *he* is interpreted as an 'abbreviated reference,' to the individual John which is denoted by the expression *John*. 

Besides coreference annotation itself, we include a set of linguistic features, in particular, those pertaining to information status ("givenness"), information status (here: backward-looking centers, "sentence topics") and auxiliary linguistic features (e.g., grammatical role and type of expression).

## 1.1 Terms

- **Coreference** is a relation between two or more textual elements, **referring expressions**, which denote the same entity. Semantically, these entities are prototypical objects or (discourse) referents. 
- **Discourse referent**: an entity that is being referred to in the discourse. Note that this does not have to be a physical entity, but it can also be an imagined entity ("the unicorn ... it ...")
- **Anaphor**: an anaphor is a referring expression that can only be interpreted by resorting to a previously mentioned co-referential expression. The preceding co-referential expression is then referred to as **antecedent**.
- **Information Status**: The degree of prominence or familiary that a referent entertains at a certain point in discourse in the common ground (or, in the discourse model).
- **Topic**: The referent that a particular is construed about. In many cases, this is a referent that entertains a high information status, and that is repeatedly referred to, and we focus on the annotation of these "familiary topics".
- **Referential chain**: We call the series of mentions of the same referent one referential chain.
- **Information Structure**: Pragmatic structure of utterances according to the distribution of information, involving, among other aspects, information status and topichood.
- **Markable**: A (potential) referential expression that is to be annotated. Syntactically, most referring expressions are noun phrases or adpositional phrases. In the current schema, we annotate the syntactic head of the markable, only, as defined by the [Universal Dependencies guidelines](https://universaldependencies.org/u/overview/nominal-syntax.html).

This annotation scheme is focusing on the annotation of referring expressions, i.e., nominal and pronominal anaphors and their information-structural features (information status, topichood). In addition to referring expressions, verbs may be annotated as *antecedents* of pronouns if these refer to the corresponding clause. We refer to these cases as **event anaphor**.

## 1.2 Referring Expressions

A *referring expression* is any linguistic form that can be used to refer to an object, person, or state of affairs (or several respectively) of the \"real world\" or a \"conceptualized world\" (as it only exists in our imagination) in a broad sense. We also include non-referring expressions, if they meet the syntactic criteria of referring expressions, e.g., \"generic terms\" such as in 

> (1) *\[The <ins>whale</ins>\] is known to be a mammal*

Referring expressions designate (refer to) a particular *discourse referent*, i.e., a conceptual object that representss an entity, person, or fact in the discourse model, resp., the common ground established between speaker and hearer during the discourse. A discourse referent is an abstract, conceptual object that exists regardless of whether it corresponds to an object of the world (or just of imagination).

Whether two markables are co-referent, i.e. referring to the same discourse referent, can be determined by a
*substitution test*. If the substitution of anaphor and antecedent yield the same interpretation of the text, these are deemed coreferential.

## 1.2 Markables

Markables<sup>[1](lit.md#terms1)</sup> represent spans in a text that carry one or more possible annotations, e.g., various attributes that characterize the type of the markable. We use the term *markable* for any element of the source text that is subject to annotation. Markables represent the basis for the subsequent annotation of coreference, information status, etc. This annotation scheme is limited to referring expressions, i.e. on (in the broadest sense) noun phrases, and their antecedents. 

If markables they are in a coreference relation, they are given an index that indicates the referent they refer to. Coreference annotation thus consists of assignment of discourse referents to markables, represented by identifiers (mnemnonics, indixes, tags) in the `COREF` column. All corerent markables should carry the same `COREF` index.

> Note: In practical annotation, annotators should not use numbers, but a meaningful, short and unambiguous abbreviation of their own choice. 

> Note: As annotation is conducted here with spreadsheet software, annotators are encouraged to use the auto-complete function that such software provides. This is most effective if indexes start with different letters.

We call the series of mentions of the same referent one *referential chain*. As result of the annotation, all elements of a referential chain must carry the same index.

> (2) *Susanne doesn't like \[gymnastics\]<sub>1</sub>, because \[it\]<sub>1</sub> is very hard.*

> (3) *At noon, \[the Federal President\]<sub>1</sub> opened \[the session\]<sub>2</sub>, and
in the evening, \[Joachim Gauck\]<sub>1</sub> closed \[it\]<sub>2</sub>\> again.*

The annotation task for is to process each text in reading order and identify all markables. As described below, this process is partially automated. After marking a markable, it can also be assigned various attributes that characterize the type of the markable. Here, this comprises annotations for referentiality (`REF`), coreference (`COREF`), information status (`IS`, "givenness") and backward-looking center (`CB`, "sentence topic"). 

These guidelines use a notation as it might be used \"on paper\" or in a text editor. For the practical procedure, see [Sect. 2](format.md). In the examples given for illustration in this document, markables are marked by <ins>underscores<ins> (for the syntactic head), or, optionally, with square brackets \[...\] to clarify the boundaries of phrasal markables. Sometimes, for the sake of clarity, not all markables are marked in an example, but only those whose status is currently being discussed.

## 1.3 Automated Pre-Annotation

In the current workflow, automated pre-annotation will create annotations for markables, for the type of referring expressions (`NP_FORM`), their grammatical roles (`GR`), and their *possible* referentiality (`REF_AUTO`, with `?OLD` as only value so far). These annotations can be corrected by the annotator, if needed.

During annotation, dynamic pre-annotation will predict possible values for `IS` and `CB`. Again, this involves auxiliary annotations used for the automated pre-annotation of `IS` and `CB` (`GR_ANTE`: grammatical role of the antecedent, `REF_DIST`: number of sentence boundaries since last mention, `REF_DIST_ANTE`: `REF_DIST` of antecedent to *its* antecedent). These auxiliary annotations should **not** be corrected by the annotator.

## 1.4 Head-based Annotation

Although this manual sometimes gives phrasal markables for illustration, we only annotate their syntactic head, as defined by the [Universal Dependencies](https://universaldependencies.org/guidelines.html) (De Marneffe et al. 2021).<sup>[2](lit.md#terms2)</sup>
 As a result, markables must never overlap.

> (4.a) English: *\[<ins>Hans</ins> -- who always had \[a soft <ins>spot</ins>\] \[for <ins>Susanne</ins>\]  -- \]  was also there.*
> (4.b) German: *\[<ins>Hans</ins> -- der immer schon \[eine <ins>Schwäche</ins>\] \[für <ins>Susanne</ins>\] hatte -- \] war auch da.*

> Note: Annotators should normally not need to decide which expression consistutes the head of a referring expression, as these are subject to automated pre-annotation.

## 1.5 About this Document

Future revisions are expected, these may include making the criteria more precise, as well as adding or amending criteria, where appropriate, or adding more examples. **However**, during an annotation campaign, these guidelines must <ins>never be changed</ins>. If an annotator feels the need for clarification or to document problematic cases, please create and provide an accompanying protocol describing the example, the problem, the decision taken for resolving or marking it in the annotation and a pointer to the data where this problem occurred. These protocols will guide subsequent revisions.

# 2. File Format and Editing

For the annotation of coreference and informaton structure, we use a tabular format and off-the-shelf spreadsheet software for annotation.

## 2.1 File Format

Following conventions for a long-standing series of shared tasks organized in conjunction with the Conference on Natural Language Learning (CoNLL) since the late 1990s, we adopt the following conventions:

- **one word per line**: One line describes one word and its annotations
- **tab-separated values**: A line consists of a fixed number of columns, separated by `<TAB>` (tabulator key)
- **empty line between sentences**: Two sentences are separated by an empty line.
- **use `#` for comments**: line starting with `#` are ignored when processing the file. Use this to add whatever additional information you want to express that doesn't fit the format otherwise.
- **put the text before every sentence**: To facilitate reading, the comment line before the sentence should contain the full text of the sentence.

This is the format for "raw" files, as produced by automated preprocessing. It can be opened in any text editor. For editing, you need to load these files in the spreadsheet software of your choice (see instructions below). The final deliverable should be one Excel (`*.xlsx`) file for every raw file, and it should have the same name (except for file extension) as the original file.

## 2.2 Raw files

The **raw files** are produced by automated pre-annotation. As part of pre-annotation, we perform tokenization (splitting words and punctuation), the detection of referring expressions, and the prediction of `?OLD` (for candidate anaphors, "primary markables") and `?NEW` (for other candidate referring expressions, "secondary markables").

Note that as part of text extracting and automated pre-annotation, some errors can occur, e.g., incorrectly split words, or incorrect type of referring expressions. **Please, do NOT fix these errors.** Instead, add a comment starting with `#` before the sentence. In your spreadsheet software, you might need to insert a row first.

The raw files currently contain three columns:

- `WORD`: words and punctuation characters as they occur in the text.
- `GR`: grammatical role
- `NP_FORM`: type of referring expression (noun phrase) 
- `REF_AUTO`: predicted referentiality, i.e., `?OLD` or empty

## 2.3 Import into Spreadsheet Software: Target Files

We provide a **template file** in `*.xlsx` format that contains a number of formulas to automatize parts of the annotation. When starting with a new raw file, say, `xyz.conll` or `xyz.tsv`, make a copy of the template file and rename it such that it matches the name of the raw file, e.g., `xyz.xlsx`. We further refer to this file as your **target file**.

The template file and the target file contain the following columns:

- `WORD`: words and punctuation characters as they occur in the text.
- `GR`: grammatical role
- `NP_FORM`: type of referring expression (noun phrase)
- `REF_AUTO`: predicted referentiality, i.e., `?OLD` or empty
- `COREF`: manual coreference annotation or `!!!` for an annotation to be done.
- `REF`: manual annotation for referentiality, automatically pre-annotated after `COREF` annotation.
- `IS`: manual annotation for information status ("givenness"), automatically pre-annotated after `COREF` annotation.
- `CB`: manual annotation for backward-looking center ("topic"), automatically pre-annotated after `COREF` annotation.
- the following columns (colored gray in template file) contain auxiliary annotations, these are not to be annotated, but part of the automated pre-annotation process
	- `GR_ANTE`: grammatical role of the antecedent (factor in `IS` and `CB` annotation)
	- `REF_DIST`: referential distance of the antecedent (factor in `IS` and `CB` annotation)
	- `REF_DIST_ANTE`: referential distance annotation of the antecedent (factor in `IS` annotation)

	> Note: In the current template file, these columns are *hidden*. They will be faithfully copied if all columns (E to L) are selected as a single block before being applied to (copied and pasted into) the following annotations (see Sect. 2.4). 

- `COMMENT`: this is a free-text column for annotators to provide information about the annotation (e.g., ambiguity), free-text comments, or pointers to more lengthy descriptions. Lengthy comments increase row height, so annotators may want to adjust column width.

| Fig. 1. Template file                              |
| -------------------------------------------------- |
| ![Screenshot from template file](img/template.png) |

Open your new file `xyz.xlsx` in your preferred spreadsheet software. You can use any tool you like, but it **must** support reading and writing MS Excel 365 files (`*.xlsx`) and they **should** support Excel formulas. Possible tools include MS Office tools, LibreOffice/OpenOffice, Google Spreadsheet (in Google Docs), etc. If you have difficulties using or getting these tools, please get in touch with your instructor.

For illustration, we use OpenOffice below. Other spreadsheet software should be similar.

Now, open the "raw" file (here, `xyz.tsv`) in your spreadsheet software. Normally, you should be able to open it by double-clicking on it. It should open as a new table. Select the entire table and copy and paste it into your target file. Make sure not to overwrite *the first three rows* of your target file (i.e., those that contain colored columns).

> Note: To select the entire table under Windows or Linux, press `<CTRL>+<END>` to get to the lower right corner of your data. Then, press `<CTRL>+<SHIFT>+<POS1>` (`<CTRL>+<SHIFT>+<HOME>`) to select everything until the upper left corner. Then, press `<CTRL>+C` to copy the entire table and `<CTRL>+V` to insert it at its new place.  Google Docs (tested under Windows/Linux) uses Windows/Linux-style keys.

> Note on MacOS: Mac keys are different. Normally, the `<MAC>` key should be used in place of `<CTRL>`.

After copying the pre-annotated data into the target file, you need to copy the *pre-annotation formulas*, too:

- Go to cell `E3` (third row, column `COREF`). The formulas are contained in the colored and the gray columns in that row. 
- Select all formulas using `<CTRL>+<SHIFt>+<LEFT>`, copy them with `<CTRL>+C`. 
- Go to cell `E4`. Press `<CTRL>+<SHIFT>+<END>` to select the table from cell `E4` to the end. Then, paste the formulas using `<CTRL>+V`. You should see colored columns for the entire text and some automated pre-annotations, now. These will update automatically during the annotation and have to be manually corrected when needed.

| Fig. 2. Target file                            |
| ---------------------------------------------- |
| ![Screenshot from target file](img/target.png) |

## 2.4 Annotation Procedure

- Annotation with spreadsheet software has a different feeling to it than just reading a text. It is highly recommended that you also look at the original plain text file, at least for a first read, before you start with with the spreadsheet annotation. 
- When doing annotation, ignore headlines. For doing so, just delete the content of the `NP_FORM` and `REF_AUTO` columns for lines you identified as headlines or other pieces of metadata ("boilerplate"). For `ted-mdb.1927`, for example, this includes the following "sentences":

	- "talkid: 1927"
	- "Chris McKnett"
	- "The investment logic for sustainability"

	> Note that this applies only to content you identify clearly as headline or boilerplate. If you are uncertain as to if a line is a headline or not, treat it as part of the text.   

- Annotate from top to bottom, just as you read. You can use the `REF_AUTO` column for quickly jumping to the next primary markable with `<CTRL>+<DOWN>`. You can go back to the last with `<CTRL>+<UP>`.
- Alternatively, you can also go to the next referring expressing with the `NP_FORM` column.

### 2.4.1 `COREF`: Coreference

- The first requirement of the task is to assign every primary markable (`?OLD`) an ID in the `COREF` column. Every discourse referent should correspond to exactly one ID, and all co-referring expressions receive the same ID.
- If a secondary markable (annotated for `NP_FORM`, but not for `REF_AUTO`) serves as antecedent for an anaphor with `COREF` ID *x*, give it the same `COREF` ID.

	> - You might want to try out for yourself if it is more convenient to either annotate all referring expressions with `COREF` or to only annotate `?OLD` expressions and then extend this to their antecedents when needed. Please drop a note on your experiences in the annotation protocol.

- For event anaphors (e.g., if `this` or `it` refers back to a preceding clause), candidate antecedents have not been marked in the `NP_FORM` column. For annotating them as antecedents, select the *main verb* of the highest (in case of conjunction, first) clause you consider as antecedent. Annotate it with the same `COREF` ID as used for the anaphor.
	
	> - Normally, the main verb expresses the semantic predicate of a clause or sentence, e.g., "The world is [changing] ...".
	> - In copula clauses, annotate the copula as antecedent, e.g., "These [are] environmental and social issues".
	> - Do not annotate `NP_FORM` for the antecedent of an event anaphor.
	> - If you have difficulties to decide which antecedent to annotate for an event anaphor, select the closest and smallest candidate, i.e., an embedded clause in favor of a main clause, the directly preceding sentence in favor of the one before, etc.

- If you encounter a non-referring `?OLD` expression, delete its `REF_AUTO` annotation (i.e., `?OLD`), but tell us which kind of non-referring expression it is using `REF`, etc.
- Use the `COMMENT` column to keep track of ambiguities or free-text comments.

### 2.4.2 `REF`: Referentiality

After annotating `COREF` for a referring expression, the `REF` column should contain the pre-annotation `OLD` or `NEW`. See the [section on coreference](coreference.md) for the meaning of these terms and other possible values. 

- Please verify or revise the pre-annotation. If it is not altered, we consider it to be approved.
- If you had to delete an `?OLD` pre-annotation for the current line, please annotate `REF` manually.
- Use the `COMMENT` column for comments on your annotation, e.g., to document problems.

### 2.4.3 `IS`: Information Status

After `COREF` and `REF` annotation, you will see pre-annotations for the `IS` column. These implement a *simplified and **incomplete** subset* of the constraints in the [corresponding section](information-status.md) that is to be manually confirmed or revised.

- Please verify or revise the pre-annotation. If it is not altered, we consider it to be approved.
- Note that the manual requires to check the applicability of annotations in a particular order. Please follow that approach here. Do **not** start with confirming the automatically pre-annotated information status, but follow the order of statuses in the manual.

### 2.4.4 `CB`: Backward-Looking Center

After `COREF` annotation, you will see pre-annotations for the `IS` column. These implement a *simplified and **incomplete** subset* of the constraints in the [corresponding section](information-status.md) that is to be manually confirmed or revised.

- Please verify or revise the pre-annotation. If it is not altered, we consider it to be approved.
- Make sure that there is at most one `CB` per sentence and that all automated annotations with question marks (indicating possible `CB` candidates) are removed.
- By automated annotation, all referring expressions with antecedents in the last sentence are marked as `CB` candidates (with question marks). Make sure to remove incorrect candidates as part of your annotation.

### 2.4.5 `COMMENT` and Annotation Protocol

The `COMMENT` column can contain free text comments or specialized tags (e.g., for ambiguity). If you want to add more than one comment, separate them by a pipe (`|`).

In addition, please create an annotation protocol as an independent document to be shared along with your file. For the target file "xyz.xslx", that should be named "xyz.log" or "xyz.log.txt". Open and edit with a text editor.

Note that this view is not suited for longer text, so, longer comments should be put into the annotation protocol, but *linked* with the annotation. For doing that linking, create the comment `NOTE(`*abbreviation*`)` in the `COMMENT` column, using an *abbreviation* of your choice (must be unique, though, you could just use numbers). In the annotation protocol, you can then create a separate paragraph starting with "NOTE(abbreviation):" and put detailed comments there.

In addition to that, you can (and should) use the annotation protocol to keep track of any observations you made during the annotation process, e.g., difficulties in interpreting or applying the annotation manual. This will guide future revision efforts.

The annotation protocol should be saved in the same folder as the target file, and (except for the file extension), it should carry the same name.

## 2.5 On Evaluation

As we rely to some extent on automated pre-annotation, we need to quantify the number of average revisions of pre-annotated values per file and annotator.

# 3. Referring Expressions

> Note to annotators: In most cases, referring expressions should be automatically pre-annotated. 
In this case, this section is not relevant for annotation, but only for you to interpret the automated pre-annotations.

> Note to developers: Additional technical details can be found in the technical appendix [WHERE].

# 3.1 Markables (things to be annotated)

Referring expressions are noun phrases, proper names and pronouns. 

- Annotate every definite noun phrase, every proper noun and every pronoun which is not syntactically bound as a potential anaphor ("primary markable").
- Check whether it has an antecedent in preceding text. If the antecedent has not been previously marked as a potential anaphor, create a new markable ("secondary markable")
- Annotate every markable as being non-referring or with the index of the coreference chain (i.e., the unique symbol that you chose to identify)

## 3.2 Manual annotation

- Please read the entire text first.
- The annotation task is to process each sentence and to annotate/verify all markables and their antecedents *in reading order*.

## 3.3 Head-based annotation

When annotating a word as markable, do not annotate the full span, but the syntactic head only. Thus, markables must never overlap.

Head identification is defined in lines of the Universal Dependencies, i.e.,

- The syntactic head of a single word span is the word
- The syntactic head of a noun phrase is the last nominal
- The syntactic head of a clause is the main verb
- The syntactic head of a prepositional phrase is the head of its noun phrase.
- The syntactic head of a multi-word proper name is the first proper noun
- The syntactic head of a conjunction is the first conjunct. If multiple conjuncts in a conjunction serve as antecedents, annotate each conjunct separately.

> (1) English: *\[<ins>Hans</ins> -- who always had \[a soft <ins>spot</ins>\] \[for <ins>Susanne</ins>\]  -- \]  was also there.*

> (2) German: *\[<ins>Hans</ins> -- der immer schon \[eine <ins>Schwäche</ins>\] \[für <ins>Susanne</ins>\] hatte -- \] war auch da.*

## 3.4 Types of candidate anaphors (primary markables)

### 3.4.1 Pronouns

Pronouns include personal pronouns, demonstrative pronouns, pronominal adverbs, and possessived pronouns and *both* in nominal use (i.e. not as a determiner),<sup>[3](lit.md#refexp3)</sup> e.g.,

> (3) *\[I\] saw \[her\] yesterday.*

We distinguish the following types:

- **Personal Pronouns** include (the language-specific counterparts of) English *I, me, you, he, him, she, her, it, we, us, they, them*.
- **Possessive Pronouns** include (the language-specific counterparts of) English *my, mine, your, yours, \...*.
- **Demonstrative Pronouns** include pronouns that establish a deictic reference. In many languages, there are multiple categories of demonstrative pronouns, e.g., proximal demonstratives in English and German (English *this, these*, *this one*, German *der, die, das, \...*) as opposed to distal demonstratives (*that, those*, *that one*, German *dieser, diese, dies(es), jener, jene, jenes, derjenige,* and the like).
- **Pronominal Adverbs** are derived from pronouns but grammaticalized as adverbs. If pronominal adverbs can still be interpreted as / replaced by a referring expression in a particular language, they should be annotated. However, we exclude references to time and place of the speaker (*here*, *hence*) if these are unambiguous in their deictic function, as well as interrogative adverbs (*where*, etc.). Pronominal adverbs in German include *da* "there, then", *dort* "there", *daneben* "next to it", *dahin* "(towards) there"), *davor* "in front of that; before that", or *deswegen* "because of that". In English, pronominal adverbs are not recognized as referring expressions in English, but they can indeed be substituted with prepositional phrases. For English, we annotate adverbs (starting with) *there* (unless expletive) and *thence*, e.g., *there*, *thereafter*, *therefore*, *thence*, *thenceforth*. We exclude the analoguous *here* and *hence* because they are exclusively deictic, not anaphoric, whereas there and thence could also have an anaphoric function (*therefore* ~ *for this reason*, *thence* ~ *from there*).

Note: In general, every pronoun should be annotated that is **formally identical** with a pronoun of the aforementioned types. This also includes certain cases of of non-referring expressions. For them, leave all fields (incl. `COREF`) empty but annotate the specific type of non-referring expression in `REF`.

Frequent cases include:

- `REF=GEN`: So-called "generic pronouns" (*we, you, they* in the sense of "anyone", in German *wir, du, sie* (without specific reference), *man, einer*).
- `REF=BOUND`: Reflexive pronouns (English *herself*, etc.) which are formally ambiguous as to whether they are reflexive or personal pronouns (e.g., German *mich* "me; myself").
- `REF=EXPL`: expletive *it*

See below [WHERE?] for forms of pronouns that are **not** to be annotated.

### 3.4.2 Definite Descriptions

A description (NP or PP) is definite if it contains the determiner *both*, a demonstrative or possessive pronoun or a genitive attribution. This includes the following sub-types:

- NP with definite article

	> (4) *\[the <ins>pizza</ins>\]*

- demonstratve NP

	> (5) *\[that <ins>pizza</ins>\]*, *\[this <ins>pizza</ins>\]*

- possessive NP (NP with possessive modifier) includes both constructions with possessive pronouns (7) and with morphologically marked possessor arguments (e.g., genitive, as in 6).

	> (6.a) *\[John\'s <ins>pizza</ins>\]*

	> (6.b) *\[the <ins>pizza</ins> of John\]*

	> (6.c) *\[the other man's <ins>pizza</ins>\]*

	> (6.d) *\[this man's <ins>pizza</ins>\]*

	> (7) *\[his <ins>pizza</ins>\]*

- **Quantified Definite NP** includes cases where a quantifier is combined with a definite article (`the two men`) or with determiner \'both\'

	> (8.a) *\[the two <ins>pizzas</ins>\]*
	> (8.b) *\[both <ins>pizzas</ins>\]*

	But not: *two pizzas*.

### 3.4.3  Proper Names and Titles

Typical instances of proper names are geographic places
(*Philadelphia*), persons (*Judge Jenkins*), companies (*Morgan
Stanley & Co.*), newspaper titles (*The New York Times*), political, social or financial institution names (*Congress, European Investment
Bank* ). 

> (10.a)  *\[Bertolt <ins>Brecht</ins>\]* (full name)

> (10.b)  *\[Bert <ins>Brecht</ins>\]* (reduced full name)

> (10.c)  *<ins>Brecht</ins>* (surname)
	
> (10.d) 	*<ins>Bertolt</ins>* (first name)
	
> (10.e) 	*<ins>Bert</ins>* (nickname)

> (10.f)   *<ins>BB</ins>* (abbreviation)

> (10.g)   *the well-known <U>Brecht</ins>* (name, modified by a definite description)

> (10.h) *<ins>Brecht</ins>, who is author of the "Dreigroschenoper"* (proper name + clause)

> (10.i) *<ins>Brecht</ins>, author of the "Dreigroschenoper"* (proper name + apposition)

Complex proper names are only treated as a single markable and are not further divided. If the internal dependency structure is transparent, annotate the syntactic head. For names composed of given and family names, we consider the name of the individual to be head, and the name of the family as modifier. If the structure of a name is not transparent to a common speaker of the language, annotate the first word that is not clearly recognizable as a modifier.
 
> (10.j) \[Dr. <ins>Mueller</ins>\]

> (10.k) \[Dr. <ins>Martin</ins> Luther King, Jr.\]

> (10.l) \[Prince <ins>Dipangkorn</ins> Rasmijoti Sirivibulyarajakumar of Thailand\]

> (10.m) \[Heidelberger <ins>Druckmaschinen</ins> Vertrieb Deutschland GmbH\]

Standalone titles that can stand in for an individual (*Mr./Ms./Dr./President/Chairman*) are treated like proper names, e.g., 

> (11.a) *Schröder<sub>1</sub>\...Fischer<sub>2</sub> \... Die anfängliche Überreaktion von <ins>Kanzler</ins><sub>1</sub> und <ins>Außenminister</ins><sub>2</sub>\...*

In (11.a), *Kanzler* and *Außenminister* have to be annotated as primary markables, because proper names are inherently definite

Parts of complex proper names cannot be analyzed separately. So, in the following example, *Petrie* in *\[of
Petrie Stores Corp.\]* should not be annotated!

> (11.b) *\[Milton Petrie, chairman \[of Petrie Stores Corp.\] said\...*

## 3.5 Other forms of referring expressions

Other forms of referring expressions are only annotated if they serve as antecedents. Note that this excludes a number of entity mentions that are introduced by an indefinite NP and not subsequently referred to.

Types of referring expressions that are unlikely or impossible anaphors include indefinite NPs and indefinite or non-referring pronouns, see X.1.4 for a detailed catalog of forms and cases.

Annotate such an expression only if you are certain about the reference. If another reading is equally possible or feels more likely, do not annotate the secondary markable. (Add a comment about your uncertainty.)

> (12) *I saw \[a <ins>cat</ins>\] tonight in the street. <ins>It(= the cat)</ins> was gray.*

**but not**: *I saw a cat tonight in the street. <ins>It(= the night/expletive?)</ins> was pitch black.*

### 3.6 Do NOT annotate

Annotate the following types of pronouns only if they either serve as antecedents of other referring expressions or they are formally ambiguous with one of the aforementioned categories.

### 3.6.1 Non-referring (`REF=GEN`, `REF=PRED`, `REF=EXPL`, `REF=other`) and bound (`REF=BOUND`) expressions

Non-referring markables (NM) are primary markables whose function is *not* to refer to a discourse referent. 
Non-referring markables are to be *manually* given the appropriate referentiality value in subsequent annotation (`GEN`, `EXPL`, `PRED`. `IDIOM` or `other`, see there). For automated extraction, they are treated like primary markables.

> Note: **TODO** merge

	- semi-demonstrative pronouns, e.g., *such*, in German *solch*. These are considered indefinite.
	- syntactically bound pronouns (relative pronouns as English *which*, etc.; reflexive pronouns such as English *himself*). If annotated as potentially referring expressions by the automated pre-annotation, they should be annotated as `REF=BOUND`
	- interrogative pronouns (English *who?*, *what?*, etc.) are not considered to be referential as they normally refer to an entity that is by definition unidentifiable to the the person asking the question. If annotated as potentially referring expressions by the automated pre-annotation, they should be annotated as `REF=CAT` (discourse cataphors) if the WH-words corresponds to a referring expression in the answer, or `REF=other` otherwise.

-   expletive expressions

	> (21) *Then, when it would have been easier to resist them, nothing was done* (expletive *it*).

-   pronominal adverbs which are controllers of relative clauses

	> (22) *Dazu kommt, dass in Werder am 24. Februar ein Bürgermeister gewählt wird und es bisher als sicher galt, dass CDU-Amtsinhaber Werner Größe unangefochten bleibt.*

	*Dazu\...dass, es\...dass* should not be annotated as markables (*Dazu* and *es* are controllers of relative clauses).

-   pronominal adverbs functioning as discourse markers

	> (23.a) *Ich habe dich angesprochen, damit du mir zuhörst*. "I am talking to you to let you know that you must listen to me."
	> (23.b) *Ich habe dir das gesagt, damit du weißt, dass du mir zuh¨oren sollst*.
	> (23.c) *Ich habe dir das gesagt, dass du weißt, dass du mir zuh¨oren sollst.*

-   relative pronouns

	If a form cannot be unambiguously classified as a relative pronoun, apply the following test: it is a relative pronoun if it can be substituted by "which" respectively "welch" in German.

	> (23.d.) *The car that went through his garden wall\...* (constructed)

	However, relative pronouns in possessive constructions (i.e. for which the test for relative pronouns fails) are annotated as possessive pronouns (see possessive NPs).

	> (24) *Und so schielen die Israelis nach Washington, an dessen /\*welchem Tropf sie wirtschaftlich und militärisch hängen,\...*
	> (24') *Und so schielen die Israelis nach Washington, das/welches sie wirtschaftlich und militärisch unterstützt* (*das* is a relative pronoun).

	Alternatively, the following test can be applied: substitute a pronoun in question with a possessive construction. If it works, you have a possessive pronoun, not a relative one.

	> (25) *die Frau und deren Kinder = die Frau und ihre Kinder*

	The annotation is as follows in this case:

	> (26) *Und so schielen \[die Israelis\]i \[(nach Washington)w, \[an \[dessen\]w Tropf\] \[sie\]i wirtschaftlich und milit¨arisch h¨angen\]<sub>w</sub>*′ *,\...*

-   prepositional phrases with prepositions *as, than*, *bis, als, wie* (in German) Such prases are annotated as normal NPs, i.e. *bis* and *als* are not included. ^3^

-   nominal premodifiers in compound nouns

	> (27) *peanut butter, airline analyst, the creditors commettee, investment bank*

	*Peanut, airline, cretitors* and *investment* are no separate markables. Note that in *the creditor's opinion*, *the creditor's* is annotated as a markable, since it is a nominal in genitive and thus not a part of a compounds.

### 1.6.2 Idioms and Collocations (`REF=IDIOM`)

Referring expressions in idioms and collocations.

> (28) *It sent Kate into the pits when she learned from her "friend" Martha, who seemed to get off on laying bad trips on people, that Harvey was getting it on with Carol.* \[Gib94, p.265\]

According to Gibbs, we find several idiomatic phrases in this example, some of which contain pronouns or full NPs -- potential primary markables.

However, they should not be annotated as such, e.g. *into the pits* meaning "to be depressed", *get it on* meaning "having sexual relations", neither *the pits* nor *it* can be referred to.

Note that we consider only *conventionalized* idiomatic expressions as idioms in our sense, i.e. markables within productive metaphors are annotated as usual, e.g. *das schlingernde City-Schiff* - a metaphor that occurred and can only be understood with respect to a specific text.


# 4. Nominal coreference 

We annotate referential chains by co-indexing all referring expressions that refer to the same referent.<sub>[1](lit.md#coref1)</sub>

##  4.1 Scope and Aim of Annotation

1. assign every referential expressing an index that unambiguously identifies its discourse referent 
2. annotate antecedents of anaphoric expressions accordingly (regardless of whether these are referring expressions or not)
3. annotate all remaining nominal and pronominal expressions as non-referential

Noun phrases, names and pronouns are automatically pre-annotated as markables. 

We annotate every markable with
- `COREF`: an abbreviation ("index") for the discourse referent (or its absence),
- `REF`: the type of reference (see below), and
- `COMMENT`: optional structured or free-text comment indicating uncertainties or design decisions. Note that this column is used for both coreference and following annotations

We do not consider syntactically bound expressions as coreferential with their controller (e.g., predicative nominals in copula sentences, or relative pronouns), as the relationship with the hypothetical antecedent is expressed by syntactic means.

## 4.2 Annotation Procedure

Annotate all referents in the order that they occur in the text with

1. `COREF` (discourse referent tag): which referent a referring expression refers to, or `_` if the expression is not referential

2. `REF` (referentiality): reference type as defined below

3. `COMMENT` (optional comment): can contain free-text comments as well as ambiguity annotations (see below).

> Note: In spreadsheet-based annotations, some of the values for refentiality are automatically suggested (`REF_AUTO`). This may help your decision for the annotation of `REF`, but please make sure to verify that properly.

Follow the following steps (and see below for additional instructions on the annotation of `REF`):

- If the markable introduces a new discourse referent, annotate it with a new index and the reference type `NEW` (or `SIT` for first person, second person or dates). This the default for indefinites and bare nouns.
- If a markable refers to previously introduced referent, annotate it with the index used for the antecedent and annotate its reference type.
- If a markable is not a referring expression, annotate it with an empty index (`_`) and annotate the type of non-reference.
- If a markable refers to two (or more) distinct, previously mentioned discourse refents ("group reference"), create a new index for the group, followed by `\>` and the comma-separated indices of all discourse referents. Assign it the reference type `GROUP`.

Use the `COMMENT` column to annotate ambiguity and provide comments as needed. If you need to come back to a passage to confirm your annotation, put that into comment, as well.

For every referent, after annotating discourse referent index and referentiality, annotate information status. In the spreadsheet, this is partially automated, but need to be confirmed.

## 4.3 Coreference (`COREF`)

For annotating coreference, use user-defined abbreviation/mnemnonic/tag that indicates which referent a referring expression refers to, or `_` if the expression is not referential.

> Note: The discourse referent tag, or "index", is an abbreviation that a user should chose at the first mention of the referent. Chains of antecedents and anaphors should all have the same index. Create abbreviations/mnemnonics as you see fit. 

> Note: If annotating **on paper**, a suitable means of annotation is with numerical indices. For reasons of space, we also follow this practice in this document. However, when doing annotation **with the computer**, numerical indices are discouraged. Instead, use mnemnonics and create meaningful abbreviations as you see fit. 

### 4.3.1 Substitution Test

A replacement test can be used to check whether a referential expression e belongs to a chain k: If it is true for every noun s (noun, proper noun) in k, that the replacement of e by s changes the interpretation of the text is not changed, then e belongs to chain k and a coreference relation to the last element of the chain is to be annotated.

According to this scheme, we only annotate coreference relations that
express a real identity between discourse objects. A "semantically loose"
connection between a definite NP and another nominal is therefore not sufficient. For this purpose the following

*Test*: To find out if two nominal descriptions are coreferent, try to substitute them with each other. (Certain transformations may be necessary, such as removing prepositions from markables.) Note that every previous coreferent markable has to be compatible with this substitution as well.

Note that this test has some issues with metonymy, i.e., substituting a word for another word closely associated with it. Cases of metonymy in text should be annotated as coreferent if and only if the subsitution test holds for all coreferring nominals: *the State Department said\... - the State Department officials claimed\...*.

> (1) *Als 1999 die im Rahmen der Dorferneuerung neu gestaltete
     \[Radeweger\]<sub>1</sub> Ablage inklusive Seebrücke mit viel Pomp eingeweiht wurde\... Doch mit der Nachrüstung tut sich \[Radewege\]<sub>1</sub> schwer \... Zu teuer, zu hässlich sei die Anlage, sagen die Meinungsführer \[im Gemeinderat\]<sub>?</sub>*  (maz-6488)

In (1), *\[Gemeinderat\]* could be considered coreferent with *\[Radewege\]<sub>1</sub>*. Yet, although both are exchangeable by means of metonymy, the substitution test fails for *\[Radewege\]<sub>1</sub>* , since *neu gestaltete Gemeinderatsablage* is not appropriate *in that context*. Accordingly, *\[Gemeinderat\]* should receive a separate index.

### 4.3.2 Event Anaphor

Pronominal event anaphors are annotated along with their antecents. 

The antecedent of an event anaphor is normally a sentence, a clause or verb phrase. If so, select the main (lexical) verb as antecedent. Hence, in this example, we annotate *gewonnen* as we encounter the referring expression *das* "this".

> (2) *Gestern hat Bayern München schon wieder gewonnen<sub>1</sub>. \[Das\]<sub>1</sub> hat Jan ziemlich gestört. Marianne hingegen war \[davon\]<sub>1</sub> begeistert.* (Non-event anaphors skipped.)

Note that antecedents of event anaphors are not automatically pre-annotated but have to be manually created.

## 4.4 Ambiguity

Ambiguity can be annotated on demand in the `COMMENT` column, see Appendix [WHERE].

### 4.4.1 Dealing with  Ambiguous Antecedents

The assignment of an antecedent will be fairly straightforward in most cases. However, it is possible that several interpretations are *equally* plausible in the eyes of the annotator. Consider ex. (3):

> (3) *Je kleiner die <ins>Kicker</ins><sub>2,OLD,AMBIG:COREF(2,1)</sub> daherkommen, desto größer wird der <ins>Gegner</ins><sub>1,OLD,AMBIG:COREF(1,2)</sub> geredet\...* (German, maz-10374)
>       "The smaller the kickers appear, the greater \[the rivals\]<sub>d?/u?</sub> are rumoured to be." (PCC, 10374)

Antecedent of die Kicker "kickers" depends on the understanding of the "size" metaphor, it can be either the Ukrainian team (presented as having short players), or the German team (which has not been favored in the first match), or a generic description (which would mean that the sentence is not directly linked with the discourse). 

If different interpretations are equally possible, apply the following disambiguation preferences in the following order:

- prefer anaphoric interpretation to antecedentless one
- for antecedents, prefer a primary markable (`REF_AUTO=?OLD`, `REF=OLD`, etc.) over a secondary markable (no `REF_AUTO`, `REF=NEW`, etc.) or a group reference
- prefer a discourse referent that is more frequently mentioned in preceding discourse
- if several discourse referents are equally frequent, prefer the last mentioned discourse referent

For the example, the generic reading is excluded by the first preference.
However, we still have the choice between two possible antecedents. The substitution test (see above) fails to determine a unique antecedent, as both possible substitutions are plausible, depending on whether "size" refers to physical size or anticipated defeat. 
The second and third criteria are designed to produce longer anaphoric chains. They result in a preference for the German team as the antecedent of die Kicker.

In annotation, then, **mark the ambiguity** (in `COMMENT`, see Appendix on details).

## 4.5 Referentiality (`REF`)

Every markable that is not assigned an antecedent is to be annotated for referentiality. 

In spreadsheet-based annotations, some of the values are automatically suggested in `REF_AUTO`. Please make sure to verify all of them. Automated pre-annotation generates the value `?OLD` for all candidate anaphors ("primary markables") and, optionally, `?NEW` for all other candidate referring expressions ("secondary markables"). 

> These values are useful for navigating in spreadsheets. They do not need to be manually corrected by the annotator. Instead, use the `REF` column to provide your own annotation. But also `?REF` can be automatically prepropulated, and any annotation project that still contains `?OLD` or `?NEW` annotations in the `REF` column will be considered incomplete and must not be further processed.

1. `OLD`: A unit of discourse that can be interpreted based on the preceding context ("discourse-old").<sup>[2](lit.md#coref2)</sup>

2. `NEW`: Discourse entity mentioned for the first time. This includes referents that can be inferred by the hearer ("discourse-new, but hearer-old"). <sup>[3](lit.md#coref3)</sup>

3. `CAT`: Discourse cataphor, i.e., reference to a new entity introduced into the discourse with an underspecified nominal expression whose exact denotation becomes clear only from subsequent descriptions. This "scene-setting" effect is a rhetorical device employed to engage readers in literary texts.<sup>[4](lit.md#coref4)</sup>

	When reading the text of the annotation example below, it is initially unclear what *Fußball-Weltmacht* and *Winzling* refer to. This becomes clear only in the next sentence, when the German team and Ukraine are mentioned.

	> Note: Syntactic cataphors are not included here. Syntactically bound pronominal cataphors are annotated as `BOUND`.

5. `GROUP`: Referring expressions that designate groups can serve as antecedents of nominal markables and can be annotated as a group. <sup>[5](lit.md#coref5)</sup>

	> (9.a) *\[Montedison\]<sub>1</sub> now owns about 72% of \[Erbamont\'s\]<sub>2</sub> shares outstanding.*

	> (9.b) *\[The companies\]<sub>3\>1,2</sub> said ... a sale of all of \[Erbamont\'s\]<sub>2</sub> assets \... \[to Montedison\]<sub>1</sub> ...*

	> (9.c) *\[The companies\]<sub>3</sub> said ...* (WSJ, 660)

	Note that the second reference to *the companies* in (9.c) is annotated as a **plain anaphoric reference** to the established group, not as a group reference to the individual companies mentioned in the meantime.

4. `BOUND`: Pronouns that are syntactically bound, e.g. reflexive pronouns. Also, possessive pronouns governed by nominal expressions in the same sentence are annotated as `BOUND`, cf. in (8.b) below *Mit <ins>seinem</ins><sub>3,BOUND</sub> Tor*.<sup>[6](lit.md#coref6)</sup>.

	> Notes: Reflexive pronouns (which are obligatorily bound) are not annotated as markables if they can be identified on grounds of their form (e.g., English *himself*, German *sich*). Only if a form is ambiguous between a reflexive and pronominal reading (e.g., German *mich*), reflexive pronouns are annotated as `BOUND`.

5. `SIT`: situationally evoked. In written texts, this applies only to first and second person, non-reflexive pronouns and to temporal expressions.<sup>[5](lit.md#coref5)</sup>

	> Note: `SIT` is to be annotated at the first mention, only, subsequent references to the same entity are to be annotated as `OLD`.

6. `GEN`: The term *generic* denotes a special usage of a referring expression, such that not a particular individual or object is meant, but rather a class of entities or features of this class.

	> (10.a) *<ins>Whales</ins><sub>GEN</sub> are <ins>mammals</ins><sub>PRED</sub>.*
	
	> (10.b)  *Der Pr¨asident wurde immer schon durch die Stimmenmehrheit bestimmt.* "The <ins>President</ins><sub>GEN</sub> has always been elected by majority <ins>vote</ins><sub>1,NEW</sub>."

	Generics should not be annotated with a discourse referent index -- unless they are subsequently referred to:

	> (10.a') *<ins>Whales</ins><sub>1,GEN</sub> are <ins>mammals</ins><sub>PRED</sub>. <ins>They</ins><sub>1,OLD</sub> descend from land <ins>animals</ins><sub>GEN</sub>.* 

	This includes both nominal and pronominal markables. Generic pronouns include certain usages of *we*, *you*, *they* (in cases where they do not carry a specific reference), *someone*, *anyone*, *one*, *many*, etc. Also cf. German *man*.

	> (11.a) *Meier said to Müller: \"\[You\]<sub>GEN</sub> should go now.\"*
	
	> (11.b) *Meier sagte zu Müller: „\[Man\]<sub>GEN</sub> sollte jetzt gehen."* (German)

	> (11.c) *Meier said to Müller: \"Last year, \[they\]<sub>GEN</sub> demolished a house here."*

	> (11.d) *Meier sagte zu Müller: „Letzes Jahr haben \[sie\]<sub>GEN</sub> hier ein Haus abgerissen."* (German)

    > (11.e) *... \[many\]<sub>GEN</sub> of the adventures* (TED-MDB 2009)

5. `EXPL`: Non-referring expression: Expletive 	expressions (English *it*) and pronominal adverbs that are controllers of relative clauses

	> (12.a) *<ins>It</ins> was raining.*

	> (12.b) *\[ <sub></sub><sub>It</sub><sub></sub> \] was also considered certain that . . .* (English)
	
	> (12.c) *\[<sub></sub><sub>Es</sub><sub></sub>\] galt zudem als sicher, dass . . .* (German)

6. `PRED`: Non-referring expression: Predicative NPs in copular sentences

	> (13.a) *Nicht, dass beide eine Mehrheit für ihre Koalition suchten, war \[das Ärgerliche in den vergangenen Tagen\] ...* (German)

	> (13.b) *The chief physician was \[a real professional\]<sub>NM</sub>.*
	
	> (13.c) *Max Müller is \[the greatest center forward of all time\]<sub>NM</sub>!*

7. `IDIOM`: Non-referring expression: apparent referring expressions (e.g., definite NPs) in fixed, conventionalized idioms and corresponding collocations:

	> (14.a) *jemandem auf die <ins>Nerven</ins> gehen* (German, "to annoy someone")
	
	> (14.b) *Er brachte mich auf \[die Palme\]<sub>NM</sub>* (German)
	
	> (14.c) *Und dann warf sie \[die Flinte\]<sub>NM</sub> \[ins Korn\]<sub>NM</sub>.* (German)

	> Note: Referring expressions in productive, transparent metaphors that are sufficiently transparent should be annotated like anaphoric expressions. The annotator may add `AMBIG:IDIOM` if not sure about their annotation. In (7.d), *der Spatz in der Hand*, a definite NP in German, can be generic, part of an idiom, or referring:

	> (14.d) *Lieber \[der Spatz in der Hand\] als \[die Taube auf dem Dach\]*    (PCC, 12666) "A bird in the hand is worth two in the bush" (Context: a mayor finds an investor for his town willing to make only minimal investments).

	> (14.e) *So lässt sich \[das schlingernde City-Schiff\]<sub>PM</sub> vielleicht doch noch auf einen erfolgversprechenden Kurs bringen.* (German, maz-18914, here, a reference to a city is made, but combined with the metaphorical image of a ship in troubled water, for which the substitution test would fail)

	Note that we also annotate apparent referring expressions in grammaticalized phrases as `IDIOM`, e.g., *in the face of* in (14.f)

	> (14.f) People in the **Face** of Modern Warfare (Fel, S., Niewiadomska, I., & Lenart-Kłoś, K. (2022). People in the Face of Modern Warfare: Relationships Between Resource Distribution and Behaviour of Participants in the Hostilities in Ukraine. V&R unipress.)

8. `other`: other, non-referring expression, please provide a description in round parentheses. Includes, for example, NPs under the scope of a negation that cannot be referred to

	> (15) *I didn\'t buy \[a new car\]<sub>NM</sub> after all.*

## 4.6 Example

> (16.a) *\[Die einstige <ins>Fußball-Weltmacht</ins>\]<sub>1,CAT</sub> zittert \[vor einem <ins>Winzling</ins>\]<sub>2,CAT,AMBIG(2,6)</sub>.*
>      "\[The former football World Power\]<sub>d</sub> is shivering \[in the face of a mite\]<sub>s</sub>."
	
> (16.b) *Mit <ins>seinem</ins><sub>3,BOUND</sub> <ins>Tor</ins><sub>4,NEW</sub> zum <ins>1:0</ins><sub>5,NEW</sub> für die <ins>Ukraine</ins><sub>6,NEW</sub> stürzte der 1,62 Meter große \[<ins>Gennadi</ins> Subow\]<sub>2,NEW</sub> die deutsche <ins>Nationalelf</ins><sub>1,NEW</sub> vorübergehend in ein <ins>Trauma</ins><sub>7,NEW</sub>.*
>       "By \[his\]<sub>s</sub> goal that set the score to 1:0 \[for Ukraine\]<sub>u</sub> pitched \[Gennadi Subow\]<sub>s</sub>, 1.62 Meter tall, \[the German National Eleven\]<sub>d</sub> in a shock for a while..."
	
> (16.c) *Je kleiner die <ins>Kicker</ins><sub>2,OLD,AMBIG:COREF(2,1)</sub> daherkommen, desto größer wird der <ins>Gegner</ins><sub>1,OLD,AMBIG:COREF(1,2)</sub> geredet\...* (German, maz-10374)
>       "The smaller the kickers appear, the greater \[the rivals\]<sub>d?/u?</sub> are rumoured to be." (PCC, 10374)

Note that here, the antecedent of die Kicker "kickers" depends on the understanding of the "size" metaphor, it can be either the Ukrainian team (presented as having short players), or the German team (which has not been favored in the first match), or a generic description (which would mean that the sentence is not directly linked with the discourse).

## 4.6 Trouble Shooting

### 4.6.1 Recurring Group Reference

Here is a very compact, constructed example:

> (17.a) Peter<sub>1</sub> and Malte<sub>2</sub> went for a walk<sub>3</sub>. Both<sub>4\>1,2</sub> wore hats<sub>5</sub>.

> (17.b) Peter<sub>1</sub> had a coat<sub>6</sub>, Malte<sub>2</sub> a rain jacket<sub>7</sub>. 

> (17.c) They<sub>**4**</sub> reached\...

When annotating *They*, note that this group has been previously established. For this reason, we do *not* refer to the second respective mentions of *Peter* and *Malte*, but instead to the previously established index for the group introduced when annotating *Both*.

### 4.6.2 Quantified NPs

Quantified expressions are either `OLD`/`GROUP` or `NEW`:

1. They are `OLD` if the same group has been previously referred to.
2. Otherwise, they are `GROUP` if they describe a finte set of entities and all these entities are mentioned before individually.
3. Otherwise, they are `OLD` if they clearly delimit the \'set of objects\'.
4. Otherwise, they are `NEW`.

Leaving the first two cases aside, a substitution substitution test helps with the decision about `OLD` and `NEW`: If we can insert a definite article or demonstrative pronoun, does that change the meaning? If not, this is referring expression.

> (18) *people* −→ *all these people* → definite description −→ referential

### 4.6.3 Pronominal Adverbs

Depending on context, some words can be either referring expressions or not. This may be automatically pre-annotated, but must be marked as non-referring in their referentiality annotation (see above).

A notorious problem in German is the annotation of pronominal adverbs such as *damit* (in the sense "so that", not in the sense "with it"), if they act as a connector: 

> (19.a) *\[Auf dem <ins>Tisch</ins>\]<sub>PM</sub> liegt \[eine <ins>Kneifzange</ins>\]<sub>SM</sub>. \[<ins>Damit</ins>\]<sub>PM</sub> kann man viel anfangen.* (German, referential *damit* "with it")

> (19.b) *\[<ins>Ich</ins>\]<sub>PM</sub> habe \[<ins>dir</ins>\]<sub>PM</sub> \[den <ins>Brief</ins>\]<sub>PM</sub> gezeigt, damit \[<ins>du</ins>\]<sub>PM</sub> bescheid weißt.* (German, non-referential *damit" "so that")

### 4.6.4 Relative Possessive Pronouns

Relative pronouns are syntactically bound and not to be annotated, but relative posessive pronouns in possessive constructions are
treated as possessive pronouns. 

> Test for German: Ein (nicht-possessives) Relativpronomen ist genau dann gegeben, wenn es durch ‚*welch*' ersetzt werden kann:

> (20.a) *Und so schielten \[die Israelis\] \[nach Washington\], \[an \[dessen\]/*∗*welchem Tropf\] \[sie\] hängen.* (maz-19074)

> (20.b) *Und so schielten \[die Israelis\] \[nach Washington, das/welches \[sie\]* *wirtschaftlich stützt\].*

### 4.6.5 Cataphora

We distinguish two types of forward-referring expressions, discourse cataphora and syntactic cataphora.

#### 4.6.5.1 Discourse Cataphora (Anaphora of Anticipation)

Discourse cataphora is a label used for non-pronominal reference forward. Sometimes an author introduces a discourse referent by means of an underspecified NP, i.e. an NP that cannot be interpreted only on the basis of the reader's knowledge up to this point. This way the author tries to encourage the reader to continue reading, in order to catch up the missing information. In the example below, *die einstige
Fußball-Weltmacht* and *vor einem Winzling* should be annotated as discourse cataphors, since their referents cannot be identified until introduced explicitly in the following text (*Deutschland* and
*Ukraine* correspondingly).

> (21) *Die einstige Fußball-Weltmacht zittert vor einem Winzling* (newspaper article title)

In case one goes on reading the text, it becomes clear that *die einstige Fußball-Weltmacht* refers to Germany, whereas *ein Winzling* refers either to the Ukraine or the 1.62 meter tall ukranian footballer who made the most impact in the match ^5^. Discourse cataphors have to be annotated as normal anaphors, i.e. in accordance with the Chain Principle (p. 12), i.e. the most recent referent mention to the left (if any) is considered to be an antecedent.

#### 4.6.5.2 Syntactic cataphora

> (22) *Through \[his\] lawyers, \[Mr. Antar\] has denied allegations in the SEC suit \...* (WSJ)

Syntactic cataphors are to be annotated like pronominal anaphora, mark referentiality as `BOUND` or `OLD`, whichever appropriate.

The following examples (a nominal head followed by a restrictive modifier), although traditionally classified as cataphora, should
NOT be annotated as such.

> (23) \... \[*the car that went through his garden wall* \]\...

> (24) \... \[*the patterns of industrial development in the U.S* \]\....

In case of doubt between syntactic cataphora or anaphora, decision has to be made as follows.

> (25.a) *Die einstige Fußball-Weltmacht zittert \[vor einem
Winzling\]s.*

> (25.b) *\[Mit \[seinem\]s Tor zum 1:0 für die Ukraine\] stürzte
\[der 1,62 Meter große Gennadi Subow\]s \[die deutsche Nationalelf\] vorübergehend in ein Trauma.*

In the example, *seinem* refers to *Gennadi Subow* who was introduced in the very first sentence as *vor einem Winzling*. Following the preferences, we establish an anaphoric (cataphoric) link to the right.
Thus, the anaphoric chain looks as follows:

-   *seinem* → *Gennadi Subow* (same-sentence)

-   *Gennadi Subow* → *vor einem Winzling* (right+previous, Chain
    Principle)


# 5. Information Status

This document is a slightly revised version of the Coding Protocol for Statuses on the Givenness Hierarchy according to Gundel et al. (1993), revision of April 2023, see Readme for authors and contributors. Note that the criteria in this coding protocol are sufficient, not necessary conditions for assigning a particular status. 

## 5.1 Givenness Hierarchy

The statuses of the Givenness Hierarchy (Gundel, Hedberg and Zacharski 1993) describe degrees of accessibility of discourse referents at a given point in discourse. In the literature, this phenomenon is referred to as *givenness*, *accessibility*, *salience*, etc. Throughout this manual, we use the term **information status** according to Lambrecht (1996). Gundel et al. originally used the term *cognitive status*.

Information status is a property of cognitive entities/mental representations. The terms IN FOCUS, ACTIVATED, FAMILIAR , UNIQUELY IDENTIFIABLE, REFERENTIAL, and TYPE IDENTIFIABLE each describe an information status on the Givenness Hierarchy (Gundel, Hedberg and Zacharski 1993). A referent IN FOCUS is considered to be higher on the hierarchy than a referent that is only TYPE IDENTIFIABLE, for example:

* IN FOCUS > ACTIVATED > FAMILIAR > UNIQUELY IDENTIFIABLE > REFERENTIAL > TYPE IDENTIFIABLE

When determining the information status using the protocol, imagine you are the speaker/writer and ask yourself what you can assume about the information status of the intended interpretation/referent for the addressee at the point just before the form is encountered. Annotate sentence by sentence. Check the criteria for each status in the order they are listed below:

1. Start with the status IN FOCUS. 
2. If none of the criteria apply, try ACTIVATED. 
3. If none of the criteria apply, try FAMILIAR.
4. If none of the criteria apply, try UNIQUELY IDENTIFIABLE.
5. If none of the criteria apply, try REFERENTIAL.
6. If none of the criteria apply, try TYPE IDENTIFIABLE.

Stop when you find a criterion that applies. This is the highest information status for the referent/interpretation you are checking.

After annotating all referents of the current sentence, annotate the CB (backward-looking center, familiarity topic) according to Centering Theory (Grosz et al. 1995).

### 5.2 IN FOCUS (`IS`=`FOCUS`)

A referent is IN FOCUS<sup>[1](lit.md#is1)</sup> if it meets at least one of the following criteria:

1.  It is the interpretation of the main clause subject or the syntactic
    topic in the immediately preceding sentence/clause (syntactic topics
    include topicalized or dislocated phrases, including topic marked
    phrases, e.g. the *wa* phrase in Japanese).

    > (1)  Midge pushed thick, wiry black hair back from her square
        forehead with a sturdy brown arm. Nothing unsubstantial or
        fairylike about <ins>her</ins>. (From *Murder after Hours*,
        Agatha Christie)

       > (2)  John Kerry lost in Ohio. This cost <ins>the Senator</ins> the
        election.

2.  It is part of the interpretation of a previous part of the same
    sentence.

    > (3.a) You can wear my scarf if you can find <ins>it.</ins>

    > (3.b) If you stand on this chair, <ins>the chair</ins> will break.

    Note that this also includes group references. In the following example, *Murillo* (Lopez' "master") is `IN FOCUS` because of a (recurring) group reference to him and Lopez appears earlier in the sentence:

    > (4)  I had excited the suspicion of Lopez<sub>l</sub>, the secretary. ... He<sub>l</sub> and his master<sub>m</sub> dragged me to my room ... They<sub>l+m</sub> had gagged me, and Murillo<sub>m</sub> twisted my arm round until I gave him the address. (AURIS, doyle_wist.02.txt)

    Similarly, Holmes in (5) is `IN_FOCUS` because he is included in the *we* reference earlier in the sentence:

    > (5) **We** moved cautiously along the track as if we were bound for the house, but **Holmes** halted us when we were about two hundred yards from it. (AURIS, doyle_bask.14.txt)

3.  It is the interpretation of the syntactic focus of the immediately
    preceding clause (i.e., postcopular position of a cleft or
    existential sentence).

    > (6.a) There was a mouse on the table. <ins>It</ins> was very large.

    > (6.b) It was the dog that Bill was afraid of. <ins>He</ins> was very
    large.

4.  It is a higher level topic that is part of the interpretation of the
    preceding clause (whether it is overtly mentioned there or not).

    > (7) The kitchen has a new countertops and a beautiful tile floor.
    There's also a big walk-through closet. Would you like to take a
    look at <ins>it</ins>? Both the kitchen (criterion 4) and the
    closet (criterion 3) are in focus.

5.  It is part of the interpretation of each of the two immediately
    preceding clauses.

    > (8) It was the dog that Bill was afraid of. Small animals didn't usually
    frighten Bill. <ins>He</ins> was very large. (*him* most likely
    to be interpreted as Bill, not the dog)

    > (9)
    >  A: She will be nice to Gerda and she will amuse Henry, and she'll
    keep John in a good temper and I'm sure she'll be most helpful with
    David --
    > B: David Angkatell?
    > A: Yes. <ins>He</ins>'s just down from Oxford. 
    > (From *Murder after Hours*, Agatha Christie)

6.  It is the event denoted by the immediately preceding sentence.

    > (10) John fell off his bike. <ins>This/it</ins> happened yesterday.

### 5.2.2 ACTIVATED (`ACTIVATED`)

A referent is ACTIVATED if it meets one of the following criteria.

1.  It is part of the interpretation of one of the immediately preceding
    two sentences.

    > (11) Central to the case was a Lewinsky-Tripp conversation that Mrs.
     Tripp taped on Dec. 22, 1997. This was the last talk between <ins>the
     two women</ins> that Mrs. Tripp recorded.

2.  It is something in the immediate spatio-temporal context that is
    activated by means of a simultaneous gesture or eye gaze.

    > (12) (looking at the wrench) Please hand me <ins>that (wrench</ins>
     (over there))

3.  It is a proposition, fact, or speech act associated with the
    eventuality (event or state) denoted by the immediately preceding
    sentence(s).

    > (13) 
    > A. John fell off his bike.
    > B. <ins>That's</ins> not true.

    > (14) 
    > A. John fell off his bike.
    > B. Can you say <ins>that</ins> again?

### 5.2.3 FAMILIAR (`FAMILIAR`)

A referent is FAMILIAR if it meets one of the following criteria.

1.  It was mentioned at any time previously in the discourse.

    > (15) A Phillipine Airlines jet with 290 people aboard was hijacked today
     by a man who took everyone's money and then parachuted to the
     ground outside Manila's airport and the passengers were let off
     safely. The jetliner left Davao City, in the southern Phillipines,
     for the 90-minute flight to Manila with 278 passengers and 12 crew
     aboard, PAL said. <ins>The hijacker</ins>, wearing a blue ski
     mask and carrying a handgun...

2.  It can be assumed to be known by the hearer through
         cultural/encyclopedic knowledge or shared personal experience
         with the speaker.

    > (16) If one takes a step back and looks at the rest of this week's
     music-group news, the situation looks bad for ugly, unpredictable
     rock 'n' roll: one of the most popular American rock bands of <ins>the
     90's.</ins>

### 5.2.4 UNIQUELY IDENTIFIABLE (`UNIQUE`)

A referent is UNIQUELY IDENTIFIABLE if it meets one of the following criteria:

1.  The referring form contains adequate descriptive/conceptual content
    to create a unique referent.

    > (17) 
    > s: hello can I help you
    > u: yeah I want t- I want to determine <ins>the maximum number of boxcars of</ins> <ins>oranges that I can get to Bath by 7 a.m. tomorrow morning</ins> so hm so I guess all the boxcars will have to go through oran- through Corning because that\'s where the orange juice factory is 
    > \[Trains Corpus. Heeman & Allen 1995\]

2.  A unique referent can be created via a 'bridging inference' by
    association with an already activated referent.(e.g. A house....the
    front door)

    > (18) She got into bed, laid her head on <ins>the pillow</ins>, and in
     two minutes was sleeping like a child. (From *Murder after Hours*,
     Agatha Christie)

    > (19) (Looking at a box) I think <ins>the bottom</ins> fell out.

### 5.2.5 REFERENTIAL (`REF`)

A referent exists, is REFERENTIAL, if it meets one of the following criteria.

1.  It is mentioned subsequently in the discourse.

    > (20) When my youngest child was 3 or so, we were at <ins>a
     friend's</ins> house visiting and my friend was babysitting
     her infant nephew.

2.  It is evident from the context that the speaker intends to refer to
    some specific entity.

    > (21) I want to tell you about <ins>this strange guy I saw today</ins>.

### 5.2.6 TYPE IDENTIFIABLE (`TYPE`)

An interpretation is TYPE IDENTIFIABLE if the sense of the phrase (the descriptive/conceptual content it encodes) is understandable.

> (22) I don't have <ins>a VCR</ins> and neither does my neighbor.

> (23) Whenever Mary passes that store, she always picks up <ins>a
     newspaper</ins>.

## 5.3 Troubleshooting

### 5.3.1 Only annotate referring expressions

If a word is annotated as `REF=GEN`, `REF=BOUND`, `REF=IDIOM` or `REF=other` (Sect. 4.5), do not annotate it for information status.

### 5.3.2 Group references

The annotation of group references is tricky if they involve referents with different information status.

- If a group was previously mentioned (as a group, i.e., `REF=OLD` in the sense of Sect. 4.5), information status is defined with reference to this last mention as a group. It does not matter whether individual members of the group have been mentioned since then.
- If a group is referred to for the first time (i.e., `REF=GROUP` in the sense of Sect. 4.5), assign it the information status of the lowest-ranking element, e.g., if it contains a `FAMILIAR` referent along with an `IN FOCUS` referent, annotate `FAMILIAR`, not `IN FOCUS`.

If a referent `X` is subsequently referred to with a group reference (either with initial group reference/`REF=GROUP` or recurring group reference/`REF=OLD`), its information status is defined as the highest status the referent can be assigned on grounds of the direct mention of a direct antecedent *or* a mention of a groups that contain it.

> Note that this applies only to groups for which the text gives an *explicit* and *exhaustive* definition. That is, a general reference to a class that includes the referent, but may also include other entities not mentioned in the text, does not count as a group reference. 



## 6. Information Structure

We provide a partial annotation of information structure, only, by focusing on information status and familiarity topics. As for the latter, we adopt the approach and the terminology of Centering Theory, and thus speak of "backward-looking center" (CB)

The topic of an utterance is defined the entity (referent) that the utterance is construed about. Traditionally, two cases are distinguished:

- **aboutness topic**: an entity in the current utterance about which the speaker wanted to provide more information.
- **familiarity topic**: the entity of the current utterance that is closest to the focus (or center) of attention (in the sense of Gundel et al. 1993), thus most likely to be the entity that the current sentence is about

The direct annotation of aboutness topics is notoriously difficult, so that we resort to the annotation of (a specific operationalization of) familiarity topics, instead.

### 6.1 Familiarity Topic

### 6.1.1 Backward-Looking Center (`CB`)

After IS annotation, CB annotation is to be done in the `CB` column.

In Centering Theory (Grosz et al. 1995), the "backward-looking center" is a technical term for the notion of "familiarity topic". The following criteria apply:<sup>[1](lit.md#topic1)</sup>

- Each sentence ("utterance") has at most one backward-looking center.
- The backward-looking center of the current sentence must be explicitly mentioned ("realized") in the immediately preceding sentence. That is, it must have been previously annotated as `IN FOCUS` or `ACTIVATED`.
- If there is more than one CB candidate that has been mentioned in the preceding sentence, check the properties of its antecendent. If an IN FOCUS expression refers to the preceding sentence or clauses within it, annotate it only as CB if no other candidate an be found. 
- Mark the expression as CB whose antecedent is highest on the following ranking ("salience ranking"):<sup>[2](lit.md#topic2)</sup>
    1. SUBJECT (of main clause, `GR`=`SBJ`)
    2. OBJECT (of main clause, e.g., direct or indirect object, `GR`=`OBJ`)
    3. OTHER  (oblique argument of main clause, e.g., prepositional phrase, `GR`=`other`), 
    4. MAIN CLAUSE (event anaphora: refer to the main clause or the full sentence, rather than any of its arguments, no `GR` annotation)
    5. SUBJECT (of dependent clause, `GR`=`SBJ_2`, `SBJ_3`, etc.)
    6. OBJECT (of dependent clause, `GR`=`OBJ_2`, `OBJ_3`, etc.)
    7. OTHER (of dependent clause, `GR`=`other_2`, `other_3`, etc.)
    8. DEPENDENT CLAUSE (event anaphora: refer to a dependent clause, no `GR` annotation)
    9. etc., for more deeply embedded dependent clauses
- If there are multiple CB candidates whose antecedent realization (according to this ranking) is identical, chose the one whose antecedent is mentioned _first_ in the preceding sentence.

CB annotation is partially pre-annotated, but has to be manually refined.

Selected CB examples:
- antecedent SUBJECT (main clause, Grosz et al. 1995, ex. 6)

    > (1.a) **Susan**  gave Betsy a pet hamster.

    > (1.b) <ins>She</ins> reminded her that such hamsters were quite shy.

- antecedent direct object (main clause, Grosz et al. 1995, ex. 18)

    > (2.a) *I'm reading **The French Lieutenant's Woman**.*
    
    > (2.b) *<ins>The book</ins>, which is Fowles's best, was a bestseller last year.*

- antecedent indirect object (main clause, Grosz et al. 1995, ex. 17)

    > (3.a) *My dog is getting quite obstreperous.*

    > (3.b) *I took **him** to the vet the other day.*

    > (3.c) *<ins>The mangy old beast</ins> always hates these visits.*

- antecedent clause

    > (4.a) * **John fell off his bike**.*
    
    > (4.b) *<ins>This/it</ins> happened yesterday.*

- antecedent SUBJECT (dependent clause, Grosz et al. 1995, ex. 2)
    
    > (5.a) *It was a store **John** had frequented for many years.*
    
    > (5.b) *<ins>He</ins> was excited that he could finally buy a piano.*

# 6.1.2 Trouble-shooting

For determining `CB` status, we consult the last direct realization of the referent. This includes two cases:

- The referent is explicitly mentioned in the last utterance, or
- The referent is indirectly evoked in a group reference that includes it and the a number of other previously entities (cf. Sect. 4.5). This can be an initial group reference (`REF=GROUP`) or a recurring group reference (`REF=OLD`)

> Note: The automated pre-annotation scripts check the first condition, but not the second. 

# 6.2 Topic Continuity: Centering Transitions (`Centering`)

Centering defines coherence relations that hold between utterance *U_i* and the preceding utterance *U_i-1*, resp., their backward-looking centers *CB(U_i)* and *CB(U_i-1)*.
Based on the identification of the backward-looking center, Centering Theory distinguishes four primary types of transitions between utterances:

- If the current utterance has no backward-looking center, annotate `NO-CB`
- If the backward-looking center of the preceding utterance is the same as the backward-looking center of the current utterance
    - If the backward-looking center is the subject of the main clause of *U_i*, then annotate `CONTINUE`
    - It the backward-looking center is not the subject of the main clause of *U_i*, then annotate `RETAIN`
- If the backward-looking center of the preceding utterance is not the same as the backward-looking center of the current utterance
    - Annotate `SHIFT`

Centering Theory then predicts that `CONTINUE` relations are more coherent than `RETAIN` than `SHIFT`.

Our texts are most written language, and sometimes the flow of utterances is interrupted by comments (e.g., "(Laughter.)", written as a sentence in a transcript) or metadata (e.g., headlines). Therefore, in cases in which the preceding utterance does not carry `CB` annotation, we consider the latest preceding utterance with a `CB`, instead. However, the centering transition is to be annotated in round brackets, then.

> **Note**: So far, Centering transitions have not been annotated yet. We expect this to be automatically derived from `CB` annotations.

> **Implementation note**: As sentence segmentation may be imperfect, consider the following possible repair technique: If previous sentence has no `CB`, resort to the last established `CB`, annotate relation in round brackets. This repair technique is designed to increase robustness against incorrect segmentations and textual fragments (e.g. headlines) interrupting the continuous flow of written text.


# A. Using the `COMMENT` column

The `COMMENT` column can (and should) be used to provide free-text information. In addition, it can also be used to provide metadata in a structured format for documenting aspects of or difficulties in the annotation. 

### A.1 Ambiguous reference

Ambiguity is to be annotated in the `COMMENT` field, using pre-defined tags (if applicable) or plain text descriptions (otherwise). Optionally, ambiguity tags can be followed by a more detailed description in round parentheses `(...)`.

The following tags can be used to mark ambiguous 

1. `AMBIG:COREF` (ambiguous antecedent):<sup>[7](lit.md#coref7)</sup> There is uncertainty as to which is the \"right\" antecedent for an anaphor (or, controller for a cataphor). See above for antecedent selection preferences, provide referent index for all equally likely antecedents in round parentheses

	> (4) *In a letter, \[prosecutors\]<sub>p</sub> told \[Mr. Antar's lawyers\]<sub>l</sub> that because of the recent Supreme Court rulings, \[they\]<sub>p/l</sub>*<sub>?</sub> *could expect that any fees collected from Mr. Antar may be seized.*

2. `AMBIG:REL`: There is uncertainty as to whether an anaphoric relation exists or which type it is (anaphoric vs. bridging or event, i.e. contextual inference)

	This is sometimes the case with definite NPs. In the example below: If it is unclear whether the *confrontation* is identical to the *conflict*, the coreference should be annotated and the markable should be marked with this attribute. It is not necessary to provide a more detailed description.

	> (5) *This <ins>conflict</ins> is ... Therefore, the <ins>confrontation</ins> ...*

3. `AMBIG:IDIOM`: There is uncertainty as to whether a markable could be understood as a referential expression or as part of an idiom. Annotate anaphoric reading and mark the ambiguity.

4. `AMBIG:EXPL`: There is uncertainty as to whether a pronoun is an expletive (and therefore non-referring) or whether it is anaphoric. Annotate the anaphoric relations and mark the ambiguity. No description necessary.

	> (6) *At stake was an \$80,000 settlement involving who should pay what share of cleanup costs at the site of a former gas station, where underground fuel tanks had leaked and contaminated the soil. And the lawyers were just as eager as the judge to wrap \[it\] up.*

	*It* can either be interpreted as referring to *an \$80,000 settlement* or as a part of a lexicalized expression *to wrap it up* where *it* does not have any particular reference. 

	This can be made clearer with a constructed example:

	> (7.a) *She looks out of the window. <ins>It</ins><sub>EXPL</sub> is dark.* (expletive)
	
	> (7.b) *Your <ins>cat</ins><sub>1</sub> has a nice color. <ins>It</ins><sub>1</sub> is dark, much more so than mine.* (anaphoric)
	
	> (7.c) *The <ins>cat</ins><sub>1</sub> is hard to see. <ins>It</ins><sub>1,AMBIG:EXPL</sub> is dark.* (ambiguous)

5. `AMBIG:COREF_REL`: There is ambiguity with respect to both antecedent and relation

	> (8) "There seems to be a move around the world to deregulate the genera- tion of electricity," Mr. Richardson said, and Canadian Utilities hopes to capitalize on it.

	*On it* refers either to *a move around the world to deregulate the generation of electricity*, or to the whole clause beginning with
	*there* and ending with *electricity* (event anaphora).

6. `AMBIG:other`: other cases of ambiguity. Please provide a description in round parentheses.

If more than one kind of ambiguity applies, e.g., both ambiguity of antecedent and ambiguity of an anaphoric relation, then provide all of the corresponding tags (and descriptions), separated by comma.



